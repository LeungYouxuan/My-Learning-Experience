package studentlevel;
import java.util.Scanner;
public class studentlevel {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc = new Scanner(System.in);
System.out.println("Please enter your student 's score.");
   int score = sc.nextInt();
   if (score>=90) {
System.out.println("The level is Excellent");
   }else if (score < 90 && score >=80) {
	System.out.println("The level is good");
   }
   else if (score >=60 && score < 80 ) {
		System.out.println("The level is Pass");
   }
   else {
	   System.out.println("The levlel is fail");
   }
   sc.close();
	}
}




	


